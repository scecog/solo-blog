title: IDEA的使用技巧
date: '2019-11-25 16:51:10'
updated: '2019-11-25 19:22:42'
tags: [工具]
permalink: /articles/2019/11/25/1574671870503.html
---
![](https://img.hacpai.com/bing/20181201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 关于方法的注释设置
1. File -> Settings -> Editor -> Live Templates 
![image.png](https://img.hacpai.com/file/2019/11/image-0bde7a6a.png)

1. 新建组 -> 新建模板
![image.png](https://img.hacpai.com/file/2019/11/image-3b18fd1c.png)
修改注释的快捷键为Enter 添加描述
1. 设置模板
```
*
 * @Description:
 $param$
 $return$
 **/
```

4. 设置模板的使用场景
![image.png](https://img.hacpai.com/file/2019/11/image-ce74a974.png)
1. 设置参数的获取方式
![image.png](https://img.hacpai.com/file/2019/11/image-a3ce50bd.png)
在param 和 return 的Default value中分别填入值
param： 
```
groovyScript("if(\"${_1}\".length() == 2) {return '';} else {def result=''; def params=\"${_1}\".replaceAll('[\\\\[|\\\\]|\\\\s]', '').split(',').toList();for(i = 0; i < params.size(); i++) {if(i==0){result+='* @param ' + params[i] + ': '}else{result+='\\n' + ' * @param ' + params[i] + ': '}}; return result;}", methodParameters());
```
return：
```
groovyScript("def returnType = \"${_1}\"; def result = '* @return: ' + returnType; return result;", methodReturnType());
```
6. 搞定，在方法写完之后使用 /* + Enter 就可以出现

# 类注释
File -> Settings -> File and Code Templates -> Class 
```
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author shichenchong@inspur.com
 * date   ${DATE} ${TIME}
 */
public class ${NAME} {
}

```

---

