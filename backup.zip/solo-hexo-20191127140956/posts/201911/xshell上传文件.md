title: xshell上传文件
date: '2019-11-25 14:06:16'
updated: '2019-11-25 14:07:27'
tags: [工具]
permalink: /articles/2019/11/25/1574661976092.html
---
![](https://img.hacpai.com/bing/20190130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# xshell上传文件使用方法
1. 连接到linux主机
2. 输入rz命令，看看是否安装了lrzsz，如果没有安装则执行yum -y install lrzsz进行安装
3. 安装成功后使用 rpm -qa | lrzsz 检查是否安装成功
4. 使用 rz -y 命令进行文件上传


